<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Autoload for the Redis library for Sparks
 *
 * @see /application/libraries/Redis.php
 */

// Add autoload for Sparks
$autoload['libraries'] = array('redis');